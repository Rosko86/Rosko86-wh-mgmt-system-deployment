﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Sоb4.xaml
    /// </summary>
    public partial class Sоb4 : Window
    {
        public Sоb4()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window1 wd1 = new Window1();
            wd1.Show();

            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Соб_421 wd1 = new Соб_421();
            wd1.Show();

            Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Соб_431 wd2 = new Соб_431();
            wd2.Show();

            Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Соб_441 wd1 = new Соб_441();
            wd1.Show();

            Close();
        }
    }
}
