﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void exit(object sender, RoutedEventArgs e)
        {
            Exit ex = new Exit();

            ex.Show();

            Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Sip1 wd2 = new Sip1();
            wd2.Show();

            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Sip2 wd1 = new Sip2();
            wd1.Show();

            Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Sip3 wd1 = new Sip3();
            wd1.Show();

            Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Sip4 wd1 = new Sip4();
            wd1.Show();

            Close();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            Sоb1 wd1 = new Sоb1();
            wd1.Show();

            Close();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Sob2 wd1 = new Sob2();
            wd1.Show();

            Close();
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            Sob3 wd1 = new Sob3();
            wd1.Show();

            Close();
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            Sоb4 wd1 = new Sоb4();
            wd1.Show();

            Close();
        }

    }
}
