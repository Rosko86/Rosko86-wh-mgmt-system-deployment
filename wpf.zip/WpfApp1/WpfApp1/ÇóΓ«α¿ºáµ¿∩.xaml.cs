﻿using System;
using System.Data.OleDb;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Авторизация.xaml
    /// </summary>
    public partial class Авторизация : Window
    {
 
        private int atteptCounter = 50;

        public Авторизация()
        {
            InitializeComponent();
        }

        private void exit(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();

            main.Show();

            Close();

        }

        private void LoginCheck(object sender, RoutedEventArgs e)
        {
            OleDbConnection conn = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0;" + $@"Data Source={AppDomain.CurrentDomain.BaseDirectory}/passwords.mdb;" + "User Id=Admin;Password=;");
            conn.Open();
            bool correct = true;

            //вход от имени пользователя
            OleDbCommand command = new OleDbCommand($"SELECT COUNT (ID) FROM users", conn);
            int count = (int)command.ExecuteScalar();

            for (int i = 1; i <= count; i++)
            {
                OleDbCommand name = new OleDbCommand($"SELECT username FROM users WHERE ID = {i}", conn);
                OleDbCommand password = new OleDbCommand($"SELECT password FROM users WHERE ID = {i}", conn);

                if (Pass.Password == password.ExecuteScalar().ToString() && loginer.Text == name.ExecuteScalar().ToString())
                {
                    MessageBox.Show("Вы успешно вошли в систему", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);

                    Window1 w1 = new Window1();
                    w1.Show();
                    Close();
                    correct = false;
                    break;
                }
            }
            //Вход с аккаунта админа
            if (Pass.Password == "1234" && loginer.Text == "admin")
            {
                MessageBox.Show("Вы успешно вошли в систему", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);

                Window1 w1 = new Window1();
                w1.Show();
                Close();
                correct = false;
            }

            //Неверный вход
            if (correct)
            {
                if (atteptCounter == 0)
                {
                    MessageBox.Show("Вы исчерпали колличество неверных вводов логина или пароля!", "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Error);
                    Application.Current.Shutdown();
                }
                else
                {
                    MessageBox.Show("Неправильный логин или пароль\nОсталось попыток: " + atteptCounter, "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Error);
                    atteptCounter--;
                }

            }

        }

    }

    }

