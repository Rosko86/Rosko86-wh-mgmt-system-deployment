﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Sоb1.xaml
    /// </summary>
    public partial class Sоb1 : Window
    {
        public Sоb1()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window1 wd1 = new Window1();
            wd1.Show();

            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Соб_121 wd1 = new Соб_121();
            wd1.Show();

            Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Соб_131 wd2 = new Соб_131();
            wd2.Show();

            Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Соб_141 wd1 = new Соб_141();
            wd1.Show();

            Close();

        }
    }
}
