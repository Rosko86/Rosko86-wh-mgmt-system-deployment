﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Сип_321.xaml
    /// </summary>
    public partial class Сип_321 : Window
    {
        public Сип_321()
        {
            
            InitializeComponent();
            //SIP321
            OleDbConnection conn = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0;" + $@"Data Source={AppDomain.CurrentDomain.BaseDirectory}/studetn1.mdb;" + "User Id=Admin;Password=;");
            conn.Open();
            OleDbCommand command = new OleDbCommand("Select * FROM SIP321", conn);
            SIP321.ItemsSource = command.ExecuteReader();
        }
        private void exit(object sender, RoutedEventArgs e)
        {

            Window1 wd1 = new Window1();
            wd1.Show();

            Close();

        }

        private void Add(object sender, RoutedEventArgs e)
        {

            if (Aboba2.Text != "")
            {
                OleDbConnection conn = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0;" + $@"Data Source={AppDomain.CurrentDomain.BaseDirectory}/studetn1.mdb;" + "User Id=Admin;Password=;");
                conn.Open();
                OleDbCommand command = new OleDbCommand($"UPDATE SIP321 SET  Экономика = {Aboba2.Text} where ID = {Aboba.Text} ", conn);
                command.ExecuteReader();
            }

            if (Aboba4.Text != "")
            {
                OleDbConnection conn = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0;" + $@"Data Source={AppDomain.CurrentDomain.BaseDirectory}/studetn1.mdb;" + "User Id=Admin;Password=;");
                conn.Open();
                OleDbCommand command = new OleDbCommand($"UPDATE SIP321 SET Производственная_практика  = {Aboba4.Text} where ID = {Aboba.Text} ", conn);
                command.ExecuteReader();
            }
            if (Aboba5.Text != "")
            {
                OleDbConnection conn = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0;" + $@"Data Source={AppDomain.CurrentDomain.BaseDirectory}/studetn1.mdb;" + "User Id=Admin;Password=;");
                conn.Open();
                OleDbCommand command = new OleDbCommand($"UPDATE SIP321 SET  Информационное_и_программное_обеспечение = {Aboba5.Text} where ID = {Aboba.Text} ", conn);
                command.ExecuteReader();
            }


        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "CSV files (*.csv)|*.csv|Text files (*.txt)|*.txt|All files (*.*)|*.*";
            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;
                SaveDataFromDatabaseToFile(filePath);
            }
        }

        // Метод для сохранения данных из базы данных в файл
        private void SaveDataFromDatabaseToFile(string filePath)
        {
            // Подключение к базе данных
            using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;" + $@"Data Source={AppDomain.CurrentDomain.BaseDirectory}/studetn1.mdb;" + "User Id=Admin;Password=;"))
            {
                conn.Open();
                OleDbCommand command = new OleDbCommand("SELECT * FROM SIP321", conn);
                OleDbDataReader reader = command.ExecuteReader();

                var sb = new StringBuilder();

                // Заголовки столбцов
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    sb.Append(reader.GetName(i) + (i == reader.FieldCount - 1 ? "\n" : ","));
                }

                // Чтение строк 
                while (reader.Read())
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        sb.Append(reader[i].ToString() + (i == reader.FieldCount - 1 ? "\n" : ","));
                    }
                }

                // Запись в файл
                File.WriteAllText(filePath, sb.ToString());
            }
        }

    }
}

