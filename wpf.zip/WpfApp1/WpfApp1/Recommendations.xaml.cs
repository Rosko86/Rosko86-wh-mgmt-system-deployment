﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Recommendations.xaml
    /// </summary>
    public partial class Recommendations : Window
    {
        public Recommendations()
        {
            InitializeComponent();
        }

        private void OK(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Если будут проблемы то прочитайте все шаги заново.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);


            Close();
           
        }

        private void exit1(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
